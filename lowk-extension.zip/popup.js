// ─────────────────────────────────────────
// BIOMETRIC ENGINE
// ─────────────────────────────────────────

const TARGET = "The quick brown fox jumps over the lazy dog";

function recordBiometrics(events) {
  const dwellTimes = [], flightTimes = [], rhythms = [];
  let totalKeys = 0, backspaces = 0;
  const kdTimes = new Map();
  let lastKU = null, lastKD = null;
  const first = events.length ? events[0].timestamp : 0;
  const last = events.length ? events[events.length - 1].timestamp : 0;

  for (const ev of events) {
    if (ev.type === "keydown") {
      kdTimes.set(ev.key, ev.timestamp);
      if (lastKD !== null) rhythms.push(ev.timestamp - lastKD);
      lastKD = ev.timestamp;
      if (lastKU !== null) flightTimes.push(ev.timestamp - lastKU);
      totalKeys++;
      if (ev.key === "Backspace") backspaces++;
    } else {
      const dt = kdTimes.get(ev.key);
      if (dt !== undefined) { dwellTimes.push(ev.timestamp - dt); kdTimes.delete(ev.key); }
      lastKU = ev.timestamp;
    }
  }

  const dur = (last - first) / 60000;
  return {
    dwellTimes, flightTimes, rhythms,
    speedWpm: dur > 0 ? (totalKeys / 5) / dur : 0,
    backspaceFreq: totalKeys > 0 ? backspaces / totalKeys : 0,
  };
}

function calcStats(vals) {
  if (!vals.length) return { mean: 0, std: 0 };
  const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
  const std = Math.sqrt(vals.reduce((a, b) => a + (b - mean) ** 2, 0) / vals.length);
  return { mean, std };
}

function buildProfile(samples) {
  const d = [], f = [], r = [], s = [], b = [];
  for (const x of samples) {
    d.push(...x.dwellTimes); f.push(...x.flightTimes);
    r.push(...x.rhythms); s.push(x.speedWpm); b.push(x.backspaceFreq);
  }
  return {
    dwellTime: calcStats(d), flightTime: calcStats(f),
    rhythm: calcStats(r), speedWpm: calcStats(s), backspaceFreq: calcStats(b),
  };
}

function scoreFeature(val, stats, eps = 0.01) {
  const dist = Math.abs(val - stats.mean) / (stats.std + eps);
  return { score: Math.max(0, Math.min(100, Math.exp(-dist * 0.5) * 100)), dist };
}

function compareToProfile(sample, profile) {
  const dwell   = scoreFeature(calcStats(sample.dwellTimes).mean, profile.dwellTime, 10);
  const flight  = scoreFeature(calcStats(sample.flightTimes).mean, profile.flightTime, 10);
  const rhythm  = scoreFeature(calcStats(sample.rhythms).mean, profile.rhythm, 10);
  const speed   = scoreFeature(sample.speedWpm, profile.speedWpm, 5);
  const bspc    = scoreFeature(sample.backspaceFreq, profile.backspaceFreq, 0.05);

  const overall =
    rhythm.score * 0.30 + dwell.score * 0.25 + flight.score * 0.25 +
    speed.score * 0.15 + bspc.score * 0.05;

  const decision = overall >= 75 ? "granted" : overall >= 50 ? "suspicious" : "denied";
  const alerts = [];
  if (rhythm.score < 50) alerts.push(`Keystroke rhythm deviation (${rhythm.dist.toFixed(1)}σ from baseline)`);
  if (dwell.score  < 50) alerts.push(`Dwell time mismatch (${dwell.dist.toFixed(1)}σ from baseline)`);
  if (flight.score < 50) alerts.push(`Flight time anomaly (${flight.dist.toFixed(1)}σ from baseline)`);
  if (speed.score  < 50) alerts.push(`Typing speed outlier (${speed.dist.toFixed(1)}σ from baseline)`);
  if (bspc.score   < 50) alerts.push(`Backspace frequency unusual (${bspc.dist.toFixed(1)}σ from baseline)`);

  return {
    score: Math.round(overall), decision, alerts,
    features: {
      rhythm: Math.round(rhythm.score), dwellTime: Math.round(dwell.score),
      flightTime: Math.round(flight.score), speed: Math.round(speed.score),
      backspace: Math.round(bspc.score),
    },
  };
}

function generateImpostor(profile) {
  const shift = v => v * (1 + (0.3 + Math.random() * 0.4) * (Math.random() > 0.5 ? 1 : -1));
  return {
    dwellTimes: [shift(profile.dwellTime.mean)],
    flightTimes: [shift(profile.flightTime.mean)],
    rhythms: [shift(profile.rhythm.mean)],
    speedWpm: shift(profile.speedWpm.mean),
    backspaceFreq: Math.max(0, shift(profile.backspaceFreq.mean)),
  };
}

// ─────────────────────────────────────────
// STORAGE
// ─────────────────────────────────────────

const LS = { u: "lk_users", c: "lk_cur", h: "lk_hist", l: "lk_last" };
const getUsers  = () => { try { return JSON.parse(localStorage.getItem(LS.u) || "{}"); } catch { return {}; } };
const saveProf  = (u, p) => { const us = getUsers(); us[u] = p; localStorage.setItem(LS.u, JSON.stringify(us)); };
const getProf   = u => getUsers()[u] || null;
const userExists = u => !!getProf(u);
const setCur    = u => localStorage.setItem(LS.c, u);
const getCur    = () => localStorage.getItem(LS.c);
const setLast   = r => localStorage.setItem(LS.l, JSON.stringify(r));
const getLast   = () => { try { const r = localStorage.getItem(LS.l); return r ? JSON.parse(r) : null; } catch { return null; } };
const getHist   = u => { try { return (JSON.parse(localStorage.getItem(LS.h) || "{}")[u]) || []; } catch { return []; } };
const addHist   = (u, e) => {
  try {
    const a = JSON.parse(localStorage.getItem(LS.h) || "{}");
    if (!a[u]) a[u] = [];
    a[u].push(e);
    if (a[u].length > 20) a[u] = a[u].slice(-20);
    localStorage.setItem(LS.h, JSON.stringify(a));
  } catch {}
};

// ─────────────────────────────────────────
// NAVIGATION
// ─────────────────────────────────────────

function show(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("on"));
  document.getElementById(id).classList.add("on");
  const isHome = id === "s-home";
  const isDash = id === "s-dash";
  const isFlow = !isHome && !isDash;
  el("nav-back").classList.toggle("hidden", !isFlow);
  el("nav-retry").classList.toggle("hidden", !isDash);
  el("nav-logout").classList.toggle("hidden", !isDash);
}

function navBack() {
  const cur = document.querySelector(".screen.on");
  if (!cur) return;
  const id = cur.id;
  if (id === "s-reg1" || id === "s-login1" || id === "s-regdone") show("s-home");
  else if (id === "s-reg2")  show("s-reg1");
  else if (id === "s-login2") show("s-login1");
  else show("s-home");
}

function doLogout() { localStorage.removeItem(LS.c); localStorage.removeItem(LS.l); show("s-home"); }
function doRetry()  { show("s-login1"); }
function el(id)     { return document.getElementById(id); }

// ─────────────────────────────────────────
// REGISTER
// ─────────────────────────────────────────

let regSamples = [], regEvents = [], regIntervals = [], regLastKD = null, regStartT = null;

function regStep1() {
  const u = el("reg-user").value.trim();
  const err = el("err-reg1");
  if (!u)            { err.textContent = "Username is required"; return; }
  if (u.length < 2)  { err.textContent = "At least 2 characters"; return; }
  if (userExists(u)) { err.textContent = "Username taken — try signing in."; return; }
  err.textContent = "";
  regSamples = []; regEvents = []; regIntervals = []; regLastKD = null; regStartT = null;
  el("reg-input").value = "";
  el("reg-wpm").textContent = "0";
  el("reg-chars").textContent = "0";
  updateRegPhrase("");
  updateRegProgress();
  show("s-reg2");
  setTimeout(() => el("reg-input").focus(), 60);
}

el("reg-input").addEventListener("keydown", e => {
  if (e.key === "Enter") { e.preventDefault(); return; }
  const now = performance.now();
  regEvents.push({ key: e.key, type: "keydown", timestamp: now });
  if (regStartT === null) regStartT = now;
  if (regLastKD !== null) regIntervals.push(now - regLastKD);
  regLastKD = now;
  updateRhythm(regIntervals);
});

el("reg-input").addEventListener("keyup", e => {
  regEvents.push({ key: e.key, type: "keyup", timestamp: performance.now() });
});

el("reg-input").addEventListener("input", () => {
  const val = el("reg-input").value;
  el("reg-chars").textContent = val.length;
  if (regStartT && val.length > 0) {
    const elapsed = (performance.now() - regStartT) / 60000;
    el("reg-wpm").textContent = elapsed > 0 ? Math.round((val.length / 5) / elapsed) : 0;
  }
  updateRegPhrase(val);

  if (val === TARGET) {
    const sample = recordBiometrics(regEvents);
    regSamples.push(sample);
    regEvents = []; regIntervals = []; regLastKD = null; regStartT = null;
    el("reg-input").value = "";
    el("reg-wpm").textContent = "0";
    el("reg-chars").textContent = "0";
    updateRegPhrase("");
    updateRhythm([]);
    updateRegProgress();

    if (regSamples.length >= 5) {
      const u = el("reg-user").value.trim();
      saveProf(u, buildProfile(regSamples));
      el("regdone-user").textContent = "user: " + u;
      show("s-regdone");
    }
  }
});

function updateRegPhrase(typed) {
  el("reg-phrase").innerHTML = TARGET.split("").map((c, i) => {
    const cls = i >= typed.length ? "char-def" : typed[i] === c ? "char-ok" : "char-err";
    return `<span class="${cls}">${c === " " ? "&nbsp;" : c}</span>`;
  }).join("");
}

function updateRegProgress() {
  const n = regSamples.length;
  el("reg-lbl").textContent = n + " / 5";
  el("reg-prog").style.width = (n / 5 * 100) + "%";
  for (let i = 0; i < 5; i++) {
    const pip = el("p" + i);
    pip.style.background = i < n ? "#00d4ff" : "rgba(0,212,255,.14)";
    pip.style.boxShadow  = i < n ? "0 0 5px rgba(0,212,255,.8)" : "none";
  }
}

function updateRhythm(intervals) {
  const svg = el("rhythm-svg");
  const W = 234, H = 40, count = 22;
  const padded = [...Array(Math.max(0, count - intervals.length)).fill(0), ...intervals.slice(-count)];
  const maxVal = Math.max(...padded, 100);
  const barW   = (W - 4) / count - 2;
  svg.innerHTML = padded.map((val, i) => {
    const h  = val === 0 ? 2 : Math.min(H - 4, (val / maxVal) * (H - 4));
    const x  = i * (barW + 2) + 1;
    const op = val === 0 ? 0.08 : 0.22 + (i / count) * 0.78;
    return `<rect x="${x.toFixed(1)}" y="${(H - h - 1).toFixed(1)}" width="${barW.toFixed(1)}" height="${h.toFixed(1)}" fill="rgba(0,212,255,${op.toFixed(2)})" rx="1.5"/>`;
  }).join("");
}

// ─────────────────────────────────────────
// LOGIN
// ─────────────────────────────────────────

let loginEvents = [], loginStartT = null;

function loginStep1() {
  const u = el("login-user").value.trim();
  const err = el("err-login1");
  if (!u)           { err.textContent = "Enter your username"; return; }
  if (!userExists(u)) { err.textContent = "No account found — register first."; return; }
  err.textContent = "";
  loginEvents = []; loginStartT = null;
  el("login-input").value = "";
  el("login-btn").disabled = true;
  el("err-login2").textContent = "";
  el("login-btn").classList.remove("hidden");
  el("login-analyzing").classList.add("hidden");
  el("login-input").disabled = false;
  el("login-avatar").textContent = u.charAt(0).toUpperCase();
  el("login-name").textContent   = u;
  updateLoginPhrase("");
  show("s-login2");
  setTimeout(() => el("login-input").focus(), 60);
}

el("login-input").addEventListener("keydown", e => {
  if (e.key === "Enter") { e.preventDefault(); if (el("login-input").value === TARGET) loginSubmit(); return; }
  const now = performance.now();
  loginEvents.push({ key: e.key, type: "keydown", timestamp: now });
  if (loginStartT === null) loginStartT = now;
});

el("login-input").addEventListener("keyup", e => {
  loginEvents.push({ key: e.key, type: "keyup", timestamp: performance.now() });
});

el("login-input").addEventListener("input", () => {
  const val = el("login-input").value;
  updateLoginPhrase(val);
  el("login-btn").disabled = val !== TARGET;
  el("err-login2").textContent = "";
});

function updateLoginPhrase(typed) {
  el("login-phrase").innerHTML = TARGET.split("").map((c, i) => {
    const cls = i >= typed.length ? "char-def" : typed[i] === c ? "char-ok" : "char-err";
    return `<span class="${cls}">${c === " " ? "&nbsp;" : c}</span>`;
  }).join("");
}

async function loginSubmit() {
  if (el("login-input").value !== TARGET) { el("err-login2").textContent = "Type the full phrase exactly."; return; }
  el("login-btn").classList.add("hidden");
  el("login-analyzing").classList.remove("hidden");
  el("login-input").disabled = true;

  await new Promise(r => setTimeout(r, 1500));

  const u = el("login-user").value.trim();
  const profile = getProf(u);
  if (!profile) { el("err-login2").textContent = "Profile not found."; return; }

  const sample = recordBiometrics(loginEvents);
  const result = compareToProfile(sample, profile);

  setCur(u);
  addHist(u, { timestamp: Date.now(), score: result.score, decision: result.decision });
  setLast(result);
  renderDashboard(u, result, profile);
}

// ─────────────────────────────────────────
// DASHBOARD
// ─────────────────────────────────────────

let _dashProfile = null;

function metricColor(v) { return v >= 75 ? "#00ff88" : v >= 50 ? "#f59e0b" : "#ef4444"; }

function gaugeMarkup(score) {
  const cx = 100, cy = 100, r = 72, rad = d => d * Math.PI / 180;
  const sx = (cx + r * Math.cos(rad(135))).toFixed(2);
  const sy = (cy + r * Math.sin(rad(135))).toFixed(2);
  const ex = (cx + r * Math.cos(rad(45))).toFixed(2);
  const ey = (cy + r * Math.sin(rad(45))).toFixed(2);
  const sw = (Math.max(0, Math.min(100, score)) / 100) * 270;
  const sa = 135 + sw;
  const fx = (cx + r * Math.cos(rad(sa))).toFixed(2);
  const fy = (cy + r * Math.sin(rad(sa))).toFixed(2);
  const la = sw > 180 ? 1 : 0;
  const col = score >= 75 ? "#00ff88" : score >= 50 ? "#f59e0b" : "#ef4444";
  const bg = `M ${sx} ${sy} A ${r} ${r} 0 1 1 ${ex} ${ey}`;
  const fg = sw < 1 ? "" : `M ${sx} ${sy} A ${r} ${r} 0 ${la} 1 ${fx} ${fy}`;
  return `<svg viewBox="0 0 200 170" width="148" height="126" style="flex-shrink:0">
    <path d="${bg}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="13" stroke-linecap="round"/>
    ${fg ? `<path d="${fg}" fill="none" stroke="${col}" stroke-width="13" stroke-linecap="round" style="filter:drop-shadow(0 0 5px ${col}80)"/>` : ""}
    <text x="100" y="106" text-anchor="middle" font-size="36" font-weight="700" fill="${col}" font-family="ui-monospace,monospace">${score}</text>
    <text x="100" y="124" text-anchor="middle" font-size="8.5" fill="rgba(255,255,255,0.28)" font-family="system-ui,sans-serif" letter-spacing="2">TRUST SCORE</text>
  </svg>`;
}

function badgeMarkup(decision) {
  const cfg = {
    granted:    { cls: "badge-g", icon: "✓", txt: "Access Granted" },
    suspicious: { cls: "badge-y", icon: "⚠", txt: "Suspicious Activity" },
    denied:     { cls: "badge-r", icon: "✕", txt: "Access Denied" },
  }[decision];
  return `<span class="badge ${cfg.cls}">${cfg.icon} ${cfg.txt}</span>`;
}

function histChartMarkup(history) {
  if (history.length < 2) return `<p style="font-size:11px;color:var(--muted);text-align:center;padding:8px 0">Log in a few more times to see history</p>`;
  const W = 370, H = 85, pL = 22, pR = 6, pT = 5, pB = 14;
  const plotW = W - pL - pR, plotH = H - pT - pB;
  const pts = history.map((h, i) => ({
    x: pL + (i / (history.length - 1)) * plotW,
    y: pT + plotH - (h.score / 100) * plotH,
    d: h.decision,
  }));
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
  const dots = pts.map(p => {
    const c = p.d === "granted" ? "#00ff88" : p.d === "suspicious" ? "#f59e0b" : "#ef4444";
    return `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3.5" fill="${c}" stroke="${c}"/>`;
  }).join("");
  const y75 = (pT + plotH - 0.75 * plotH).toFixed(1);
  const y50 = (pT + plotH - 0.50 * plotH).toFixed(1);
  return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
    <line x1="${pL}" y1="${y75}" x2="${W - pR}" y2="${y75}" stroke="rgba(0,255,136,.2)" stroke-dasharray="4 3"/>
    <line x1="${pL}" y1="${y50}" x2="${W - pR}" y2="${y50}" stroke="rgba(245,158,11,.2)" stroke-dasharray="4 3"/>
    <text x="${pL - 3}" y="${parseFloat(y75) + 3}" text-anchor="end" font-size="8" fill="rgba(255,255,255,.22)">75</text>
    <text x="${pL - 3}" y="${parseFloat(y50) + 3}" text-anchor="end" font-size="8" fill="rgba(255,255,255,.22)">50</text>
    <path d="${path}" fill="none" stroke="rgba(0,212,255,.45)" stroke-width="1.5"/>
    ${dots}
  </svg>`;
}

function renderDashboard(u, result, profile) {
  _dashProfile = profile;

  el("dash-gauge").innerHTML = gaugeMarkup(result.score);
  el("dash-badge").innerHTML = badgeMarkup(result.decision);
  el("dash-desc").textContent = {
    granted:    "Your typing pattern matches your enrolled profile. Identity confirmed.",
    suspicious: "Moderate biometric deviation. Possible unauthorized access — review alerts.",
    denied:     "Significant mismatch. This pattern does not match your profile.",
  }[result.decision];

  const f = result.features;
  [["rhythm", f.rhythm], ["dwell", f.dwellTime], ["flight", f.flightTime], ["speed", f.speed]].forEach(([k, v]) => {
    const c = metricColor(v);
    el("m-" + k).textContent = v + "%";
    el("m-" + k).style.color = c;
    el("mb-" + k).style.width = v + "%";
    el("mb-" + k).style.background = c;
  });

  el("dash-alerts").innerHTML = result.alerts.map(a =>
    `<div class="alert-item"><span style="flex-shrink:0">⚠</span>${a}</div>`
  ).join("");

  const hist = getHist(u);
  el("hist-lbl").textContent = hist.length + " logins";
  el("dash-chart").innerHTML = histChartMarkup(hist);

  el("imp-result").classList.add("hidden");
  el("imp-btn").textContent = "Run";
  el("imp-btn").disabled = false;

  show("s-dash");
}

async function runImpostor() {
  if (!_dashProfile) return;
  const btn = el("imp-btn");
  btn.textContent = "..."; btn.disabled = true;
  await new Promise(r => setTimeout(r, 1000));

  const imp = generateImpostor(_dashProfile);
  const res = compareToProfile(imp, _dashProfile);

  el("imp-score").textContent = res.score + "%";
  el("imp-badge").innerHTML = badgeMarkup(res.decision);
  el("imp-alerts").innerHTML = res.alerts.map(a =>
    `<div style="font-size:11px;color:rgba(239,68,68,.8);display:flex;gap:5px;margin-top:4px"><span>⚠</span>${a}</div>`
  ).join("");

  el("imp-result").classList.remove("hidden");
  btn.textContent = "Run Again"; btn.disabled = false;
}

// ─────────────────────────────────────────
// INIT — restore session on popup open
// ─────────────────────────────────────────

(function init() {
  const cur  = getCur();
  const last = getLast();
  if (cur && last) {
    const prof = getProf(cur);
    if (prof) { renderDashboard(cur, last, prof); return; }
  }
  show("s-home");
})();
